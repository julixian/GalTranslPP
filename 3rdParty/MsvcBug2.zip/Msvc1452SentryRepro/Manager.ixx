module;

#include "classic_header.hpp"

export module Manager;
