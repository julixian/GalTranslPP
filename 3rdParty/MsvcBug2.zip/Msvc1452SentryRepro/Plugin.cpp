module;

#include "classic_header.hpp"

module Plugin;

namespace repro {
    int Plugin::run(const char* text) const {
        return dotted_first_part_nonempty(text) ? 1 : 0;
    }
}
