module;

#include "classic_header.hpp"

export module Plugin;

import Base;
import Manager;

export namespace repro {
    class Plugin {
    public:
        int run(const char* text) const;
    };
}
