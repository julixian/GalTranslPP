# MSVC 14.52 C++ modules `std::getline` regression repro

## Summary

MSVC 14.52.36405 fails with C2079 when compiling a named-module implementation unit that instantiates `std::getline` from an inline function defined in a classic header. The failure happens only when another imported module interface has also included that same classic header in its global module fragment.

The repro does not depend on the original project or any third-party library. It only uses the MSVC toolset, C++20 modules, STL modules, and the standard library headers `<sstream>` and `<string>`.

## Environment

Known-good toolset:

```text
D:\VisualStudio2026\MSBuild\Current\Bin\amd64\MSBuild.exe
MSBuild 18.6.3
MSVC 14.50.35717
```

Known-bad toolset:

```text
D:\Microsoft Visual Studio\MSBuild\Current\Bin\amd64\MSBuild.exe
MSBuild 18.7.1
MSVC 14.52.36405
```

Project settings:

```text
Configuration: Release
Platform: x64
PlatformToolset: v145
LanguageStandard: /std:c++latest
EnableModules: true
BuildStlModules: true
RuntimeLibrary: /MD
```

## Repro steps

From the parent directory of `Msvc1452SentryRepro`, run:

```powershell
& 'D:\Microsoft Visual Studio\MSBuild\Current\Bin\amd64\MSBuild.exe' `
  'Msvc1452SentryRepro\Msvc1452SentryRepro.vcxproj' `
  /t:Rebuild /p:Configuration=Release /p:Platform=x64 `
  /p:VCToolsVersion=14.52.36405 /p:MSVCPreviewEnabled=true `
  /m:1 /v:minimal
```

Expected: build succeeds.

Actual with MSVC 14.52.36405:

```text
include\string(32,34): error C2079: "_Ok" uses undefined class
"std::basic_istream<char,std::char_traits<char>>::sentry"
```

The same project succeeds with MSVC 14.50.35717:

```powershell
& 'D:\VisualStudio2026\MSBuild\Current\Bin\amd64\MSBuild.exe' `
  'Msvc1452SentryRepro\Msvc1452SentryRepro.vcxproj' `
  /t:Rebuild /p:Configuration=Release /p:Platform=x64 `
  /p:VCToolsVersion=14.50.35717 `
  /m:1 /v:minimal
```

## CMD commands

Run these in `cmd.exe`:

```bat
rmdir /s /q Msvc1452SentryRepro\x64
"D:\VisualStudio2026\MSBuild\Current\Bin\amd64\MSBuild.exe" Msvc1452SentryRepro\Msvc1452SentryRepro.vcxproj /t:Rebuild /p:Configuration=Release /p:Platform=x64 /p:VCToolsVersion=14.50.35717 /m:1 /v:minimal

rmdir /s /q Msvc1452SentryRepro\x64
"D:\Microsoft Visual Studio\MSBuild\Current\Bin\amd64\MSBuild.exe" Msvc1452SentryRepro\Msvc1452SentryRepro.vcxproj /t:Rebuild /p:Configuration=Release /p:Platform=x64 /p:VCToolsVersion=14.52.36405 /p:MSVCPreviewEnabled=true /m:1 /v:minimal
```

## Minimal trigger shape

`classic_header.hpp`:

- includes `<sstream>` and `<string>`
- defines an inline function that creates `std::istringstream` and calls `std::getline`

`Manager.ixx`:

- has a global module fragment
- includes `classic_header.hpp`
- exports module `Manager`

`Plugin.ixx`:

- has a global module fragment
- includes `classic_header.hpp`
- exports module `Plugin`
- imports `Manager`

`Plugin.cpp`:

- has a global module fragment
- includes `classic_header.hpp`
- is an implementation unit of module `Plugin`
- calls the inline function from `classic_header.hpp`

Removing `import Manager;` from `Plugin.ixx`, or removing the `classic_header.hpp` include from either module interface, makes the failure disappear.
