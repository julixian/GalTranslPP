#pragma once

#include <sstream>
#include <string>

namespace repro {
    inline bool dotted_first_part_nonempty(const std::string& input) {
        std::istringstream stream(input);
        std::string part;
        return std::getline(stream, part, '.') && !part.empty();
    }

}
